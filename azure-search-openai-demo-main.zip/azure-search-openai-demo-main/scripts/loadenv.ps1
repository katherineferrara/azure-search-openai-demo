./scripts/load_azd_env.ps1

./scripts/load_python_env.ps1
